create definer = root@localhost trigger trg_after_internship_insert
    after insert
    on internships
    for each row
BEGIN
    INSERT INTO internship_stats (user_id, total_count, related_count)
    VALUES (NEW.user_id, 1, IF(NEW.is_related = 1, 1, 0))
    ON DUPLICATE KEY UPDATE
        total_count = total_count + 1,
        related_count = related_count + IF(NEW.is_related = 1, 1, 0);
END;

