create definer = root@localhost trigger trg_after_internship_delete
    after delete
    on internships
    for each row
BEGIN
    UPDATE internship_stats
    SET total_count = total_count - 1,
        related_count = related_count - IF(OLD.is_related = 1, 1, 0)
    WHERE user_id = OLD.user_id;
END;

